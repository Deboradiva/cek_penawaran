<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari formulir
    $tanggal = $_POST["tanggal"];
    $fortofolio = $_POST["fortofolio"];
    $status = $_POST["status"];

    // Tambahkan id_pekerja_jasa sesuai dengan kebutuhan, atau ambil dari sesi login jika digunakan
    $id_pekerja_jasa = 1; // Ganti dengan nilai sesuai kebutuhan

    // Insert data ke database
    $sql = "INSERT INTO menawarkan_jasa (tanggal, fortofolio, status, id_pekerja_jasa) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    // Bind parameter ke statement
    $stmt->bind_param("sssi", $tanggal, $fortofolio, $status, $id_pekerja_jasa);

    // Eksekusi statement
    if ($stmt->execute()) {
        echo "Data berhasil disubmit!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Tutup statement
    $stmt->close();
} else {
    echo "Akses tidak sah!";
}

// Tutup koneksi
$conn->close();
?>
