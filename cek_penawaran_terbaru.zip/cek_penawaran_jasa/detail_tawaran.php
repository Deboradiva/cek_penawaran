<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Tawaran</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.18.0/font/bootstrap-icons.css">

    <style>
        .aksenImg {
            float: right; /* Menempatkan gambar di sebelah kanan */
            width: 100px; /* Mengatur lebar gambar */
            height: auto; /* Menjaga rasio aspek gambar */
            margin-left: 10px; /* Memberi jarak antara gambar dan kontennya */
        }
    </style>

</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
                <div class="container">
                    <a class="navbar-brand" href="#"><img class="logoImg" src="Logo.png" alt="" /></a>
                    <div class="container-fluid">
                        <!-- <a class="navbar-brand" href="#"><img src="logo.png"></a> -->
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                    </div>
                    
                
                    
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="#kategori">Kategori</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#portofolio">Portofolio</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#testimoni">Testimoni</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#cara_kerja">Cara Kerja</a>
                            </li>
                        </ul>
                    
                

                        <ul class="navbar-nav ms-auto">
                            <?php 
                                if(isset($login)){
                            ?>
                            <li class='nav-item'><a class='nav-link' aria-current='page' href='#'>Login<i class='uil uil-signin'></i></a></li>
                            <li class='nav-item mx-3 mt-2'><div class='pemisahLogin'></div></li>
                            <li class='nav-item'><a class='nav-link' href='#'>Register <i class='uil uil-user'></i></a></li>
                            <?php 
                            }else{
                            ?>
                            <li class='nav-item'><a class='nav-link' aria-current='page' href=''><?= "Login" ?></a></li>
                            <li class='nav-item'><a class='nav-link' aria-current='page' href='#'>Logout <i class="uil uil-sign-in-alt"></i></a></li>
                            <?php 
                            }
                            ?>
                        </ul>
                    </div>
                </div>
    </nav>

            <!-- AKSEN IMG -->
            <img src="aksen.png" alt="" class="aksenImg" />
    
    <div class="container" style="margin-top:50px">
        <h2>Tawaran Project</h2>
        <h5>Daftar Project</h5>
        <a href="cek_penawaran.php" class="btn btn-warning">Kembali</a>
        <h6>Detail Tawaran</h6>
        <!-- <div class="search-box">
            <input type="text" class="search-input" placeholder="Invoice / Project / Talent">
            <button class="search-button">Cari</button>
        </div><br> -->
        <div class="card mb-3" style="max-width: 1500px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <a href="" target="_blank">
                        <i class="bi bi-tiktok"></i>
                        <img src="tiktok.jpg" class="img-fluid rounded-start" alt="Logo Tiktok">
                    </a>
                </div>
                <div class="col-md-8">
                    <div class="card-body" style="height: 100%">
                        <h5 class="card-title">Design 3D Animation Logo for Youtube | 3D Blender</h5>
                        <p class="card-text">Anggaran : Rp 1.000.000</p>
                        <p class="card-text">Tenggat  : 10 Hari</p>
                        <p class="card-text">Kategori : Logo Design</p>
                        <br>    
                        <br>

                        <div class="card bg-light text-dark">
                            <div class="card-body">Nama : Putri <br>
                            <?php
                            // handle_status.php

                            if (isset($_GET['status'])) {
                                $status = $_GET['status'];

                                // Perform actions based on the status
                                if ($status === 'reject') {
                                    // Handle rejection logic here
                                    echo "STATUS : REJECT";
                                } elseif ($status === 'accept') {
                                    // Handle acceptance logic here
                                    echo "STATUS : ACCEPT";
                                } else {
                                    echo "Invalid status.";
                                }
                            } else {
                                echo "Status parameter not set.";
                            }
                            ?>
                            </div>
                            <a href="detail_orang_1.php" class="btn btn-info">Selengkapnya</a>
                        </div>
                        <br>
                        <div class="card bg-light text-dark">
                            <div class="card-body">Nama : Bella <br>
                            <?php
                            // handle_status.php

                            if (isset($_GET['status'])) {
                                $status = $_GET['status'];

                                // Perform actions based on the status
                                if ($status === 'reject') {
                                    // Handle rejection logic here
                                    echo "STATUS : REJECT";
                                } elseif ($status === 'accept') {
                                    // Handle acceptance logic here
                                    echo "STATUS : ACCEPT";
                                } else {
                                    echo "Invalid status.";
                                }
                            } else {
                                echo "Status parameter not set.";
                            }
                            ?>
                            </div>
                            <a href="detail_orang_2.php" class="btn btn-info">Selengkapnya</a>
                        </div>
                        <br>
                        <div class="card bg-light text-dark">
                            <div class="card-body">Nama : Yusuf <br>
                            <?php
                            // handle_status.php

                            if (isset($_GET['status'])) {
                                $status = $_GET['status'];

                                // Perform actions based on the status
                                if ($status === 'reject') {
                                    // Handle rejection logic here
                                    echo "STATUS : REJECT";
                                } elseif ($status === 'accept') {
                                    // Handle acceptance logic here
                                    echo "STATUS : ACCEPT";
                                } else {
                                    echo "Invalid status.";
                                }
                            } else {
                                echo "Status parameter not set.";
                            }
                            ?>
                            </div>
                            <a href="detail_orang_3.php" class="btn btn-info">Selengkapnya</a>
                        </div>
                        <br>
                        <div class="card bg-light text-dark">
                            <div class="card-body">Nama : Joshua <br>
                            <?php
                            // handle_status.php

                            if (isset($_GET['status'])) {
                                $status = $_GET['status'];

                                // Perform actions based on the status
                                if ($status === 'reject') {
                                    // Handle rejection logic here
                                    echo "STATUS : REJECT";
                                } elseif ($status === 'accept') {
                                    // Handle acceptance logic here
                                    echo "STATUS : ACCEPT";
                                } else {
                                    echo "Invalid status.";
                                }
                            } else {
                                echo "Status parameter not set.";
                            }
                            ?>
                            </div>
                            <a href="detail_orang_4.php" class="btn btn-info">Selengkapnya</a>
                        </div>
                        <br>
                        <!-- <a href="#" class="btn btn-outline-danger">Reject</a> -->
                        <!-- <a href="#" class="btn btn-outline-dark">Accept</a> -->

                        <!-- <a href="detail_tawaran.php" class="btn btn-primary">Lihat detail Tawaran</a> -->
                        <!-- <button class="submit">Lihat Detail Tawaran</button> -->
                    </div>
                </div>
            </div>
        </div>
        <!--  -->
        <!-- <div class="card mb-3" style="max-width: 540px; height:100%">
            <div class="row g-0">
                <div class="col-md-4">
                    <a href="" target="_blank">
                        <i class="bi bi-tiktok"></i>
                        <img src="sm.jpeg" class="img-fluid rounded-start" alt="Logo Tiktok">
                    </a>
                </div>
                <div class="col-md-8">
                    <div class="card-body" style="height: 100%">
                        <h5 class="card-title">Design 3D Animation Logo for Youtube | 3D Blender</h5>
                        <p class="card-text">Anggaran : Rp 1.000.000</p>
                        <p class="card-text">Tenggat  : 10 Hari</p>
                        <p class="card-text">Kategori : Logo Design</p>
                        <p class="card-text"><small class="text-body-secondary">Last updated 3 mins ago</small></p>
                        <a href="detail_tawaran.php" class="btn btn-primary">Lihat Detail Tawaran</a>
                    </div>
                </div>
            </div>
        </div> -->
    </div>
</body>
</html>