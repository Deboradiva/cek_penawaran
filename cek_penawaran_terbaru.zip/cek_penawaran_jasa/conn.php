<?php
// Buat koneksi ke database
$conn = new mysqli("localhost", "root", "", "pekerjaan_request");

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data foto dari database
$sql = "SELECT foto FROM foto WHERE id = 1"; // Gantilah dengan nama tabel dan kolom yang sesuai
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $foto = $row["foto"];
    // Lakukan sesuatu dengan data foto (misalnya, tampilkan atau simpan dalam file)
} else {
    echo "Data foto tidak ditemukan";
}

// Tutup koneksi
$conn->close();
?>
