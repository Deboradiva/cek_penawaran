<?php
    $localhost = "localhost";
    $root = "root";
    $password = "";
    $database = "db_freelancer";
  
    $koneksi = mysqli_connect($localhost, $root, $password, $database);
    $query = "SELECT * FROM pekerja_jasa ";
    $result = mysqli_query($koneksi, $query);
  
    if(isset($_POST['delete'])){
      $id_user = $_POST['id_user'];
      $query_delete = "DELETE FROM pekerja_jasa WHERE id_user = $id_user";
      mysqli_query($koneksi, $query_delete);
      header('Location:freelancer.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Tawaran</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.18.0/font/bootstrap-icons.css">

    <style>
        .aksenImg {
            float: right; /* Menempatkan gambar di sebelah kanan */
            width: 100px; /* Mengatur lebar gambar */
            height: auto; /* Menjaga rasio aspek gambar */
            margin-left: 10px; /* Memberi jarak antara gambar dan kontennya */
        }
    </style>

</head>
<body>
    
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
                <div class="container">
                    <a class="navbar-brand" href="#"><img class="logoImg" src="Logo.png" alt="" /></a>
                    <div class="container-fluid">
                        <!-- <a class="navbar-brand" href="#"><img src="logo.png"></a> -->
                        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                    </div>
                    
                
                    
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="#kategori">Kategori</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#portofolio">Portofolio</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#testimoni">Testimoni</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#cara_kerja">Cara Kerja</a>
                            </li>
                        </ul>
                    
                

                        <ul class="navbar-nav ms-auto">
                            <?php 
                                if(isset($login)){
                            ?>
                            <li class='nav-item'><a class='nav-link' aria-current='page' href='#'>Login<i class='uil uil-signin'></i></a></li>
                            <li class='nav-item mx-3 mt-2'><div class='pemisahLogin'></div></li>
                            <li class='nav-item'><a class='nav-link' href='#'>Register <i class='uil uil-user'></i></a></li>
                            <?php 
                            }else{
                            ?>
                            <li class='nav-item'><a class='nav-link' aria-current='page' href=''><?= "Login" ?></a></li>
                            <li class='nav-item'><a class='nav-link' aria-current='page' href='#'>Logout <i class="uil uil-sign-in-alt"></i></a></li>
                            <?php 
                            }
                            ?>
                        </ul>
                    </div>
                </div>
    </nav>

            <!-- AKSEN IMG -->
            <img src="aksen.png" alt="" class="aksenImg" />
    
    <div class="container" style="margin-top:50px">
        <h2>Tawaran Project</h2>
        <h5>Daftar Project</h5>
        <a href="detail_tawaran.php" class="btn btn-warning">Kembali</a>
        <br>
        <h6>Detail Tawaran</h6>

        <!-- Card -->

        <div class="card mb-3" style="max-width: 1500px;">
            <div class="row g-0">
                <div class="col-md-4">
                    <a href="" target="_blank">
                        <i class="bi bi-tiktok"></i>
                        <img src="yoona.jpg" class="img-fluid rounded-start" alt="Logo Tiktok">
                    </a>
                </div>
                <br>          

                <div class="col-md-8">
                    <div class="card-body" style="height: 100%">
                    
                        <div class="row">
                            <div class="col">
                            <label for="comment"><b>Nama Depan</b></label>
                            <!-- menampilkan db -->
                            <?php
                            $tampil = mysqli_query($koneksi, "SELECT nama_pertama FROM pekerja_jasa order by id_kategori_pekerja desc");
                            
                            // cek apakah query berhasil dijalankan
                            if ($tampil){
                                // Fetch data dari hasil query
                                $database = mysqli_fetch_assoc($tampil);

                                // Tampilkan data nama depan di dalam input readonlu
                                echo '<input type="text" class="form-control" placeholder="" name="nama_pertama" value="' . $database['nama_pertama'] . '" readonly>';
                            } else {
                                // Tampilkan pesan kesalahan jika query gagal
                                echo "Error: " . mysqli_error($koneksi);
        
                            }
                            ?>
                            
                            <!-- <input type="text" class="form-control" placeholder="" name="nama_depan" readonly> -->
                            </div>
                            <div class="col">
                            <label for="comment"><b>Nama Belakang</b></label>  
                            <?php
                            // Query untuk mengambil data nama belakang dari tabel pekerja_jasa
                            $tampil_terakhir = mysqli_query($koneksi, "SELECT nama_terakhir FROM pekerja_jasa ORDER BY id_kategori_pekerja DESC");

                            // Cek apakah query berhasil dijalankan
                            if ($tampil_terakhir) {
                                // Fetch data dari hasil query
                                $database_terakhir = mysqli_fetch_assoc($tampil_terakhir);

                                // Tampilkan data nama belakang di dalam input readonly
                                echo '<input type="text" class="form-control" placeholder="" name="nama_terakhir" value="' . $database_terakhir['nama_terakhir'] . '" readonly>';
                            } else {
                                // Tampilkan pesan kesalahan jika query gagal
                                echo "Error: " . mysqli_error($koneksi);
                            }    
                            ?>  
                            <!-- <input type="text" class="form-control" placeholder="" name="nama_terakhir" readonly> -->
                            
                            </div>
                        </div>
                        
                        <br> 
                        <label for="comment"><b>Kategori</b></label>
                        <!-- menampilkan -->
                        <?php
                        // Query untuk mengambil data nama_kategori dari tabel kategori_pekerja
                        $tampil_kategori = mysqli_query($koneksi, "SELECT nama_kategori FROM kategori_pekerja ORDER BY id_kategori_pekerja DESC");

                        // Cek apakah query berhasil dijalankan
                        if ($tampil_kategori) {
                            // Fetch data dari hasil query
                            $database_kategori = mysqli_fetch_assoc($tampil_kategori);

                            // Tampilkan data nama_kategori di dalam input readonly
                            echo '<input type="text" class="form-control" placeholder="" name="nama_kategori" value="' . $database_kategori['nama_kategori'] . '" readonly>';
                        } else {
                            // Tampilkan pesan kesalahan jika query gagal
                            echo "Error: " . mysqli_error($koneksi);
                        }
                        ?>
                        <!-- <input type="text" class="form-control" placeholder="" readonly> -->
                        <br>

                        <label for="comment"><b>Portofolio</b></label><br>
                        <!-- menampilkan -->
                        <?php
                        // Query untuk mengambil data file_cv dari tabel pekerja_jasa
                        $tampil_cv = mysqli_query($koneksi, "SELECT cv FROM pekerja_jasa ORDER BY cv DESC");

                        // Cek apakah query berhasil dijalankan
                        if ($tampil_cv) {
                            // Fetch data dari hasil query
                            $database_cv = mysqli_fetch_assoc($tampil_cv);

                            // Tampilkan tombol untuk membuka file CV
                            echo '<a href="path/to/cv_directory/' . $database_cv['cv'] . '" target="_blank" class="btn btn-primary">Buka CV</a>';
                        } else {
                            // Tampilkan pesan kesalahan jika query gagal
                            echo "Error: " . mysqli_error($koneksi);
                        }
                        ?>
                        <!-- <input type="file" class="form-control-file" id="gambar" name="gambar" required> -->
                        <br>

                        <label for="comment"><b>Published Budget</b></label>
                        <!-- Menampilkan budget -->
                        <?php
                        // Query untuk mengambil data harga dari tabel pekerjaan_request
                        $tampil_harga = mysqli_query($koneksi, "SELECT harga FROM pekerjaan_request ORDER BY id_pekerjaan DESC");

                        // Cek apakah query berhasil dijalankan
                        if ($tampil_harga) {
                            // Fetch data dari hasil query
                            $database_harga = mysqli_fetch_assoc($tampil_harga);

                            // Tampilkan data harga di dalam input readonly
                            echo '<input type="text" class="form-control" placeholder="" name="harga" value="' . $database_harga['harga'] . '" readonly>';
                        } else {
                            // Tampilkan pesan kesalahan jika query gagal
                            echo "Error: " . mysqli_error($koneksi);
                        }
                        ?>
                        <!-- <input type="text" class="form-control" placeholder=""readonly> -->
                        <br>

                        <label for="comment"><b>Penghasilan yang Diinginkan</b></label>
                        <input type="text" class="form-control" placeholder="">
                        <br>

                        <label for="comment"><b>Deskripsi Pekerjaan/Ringkasan</b></label>
                        <!-- menampilkan -->
                        <?php
                        // Query untuk mengambil data deskripsi_pekerjaan dari tabel pekerjaan_request
                        $tampil_deskripsi = mysqli_query($koneksi, "SELECT deskripsi_pekerjaan FROM pekerjaan_request ORDER BY id_pekerjaan DESC");

                        // Cek apakah query berhasil dijalankan
                        if ($tampil_deskripsi) {
                            // Fetch data dari hasil query
                            $database_deskripsi = mysqli_fetch_assoc($tampil_deskripsi);

                            // Tampilkan data deskripsi_pekerjaan di dalam textarea readonly
                            echo '<textarea class="form-control" name="deskripsi_pekerjaan" readonly>' . $database_deskripsi['deskripsi_pekerjaan'] . '</textarea>';
                        } else {
                            // Tampilkan pesan kesalahan jika query gagal
                            echo "Error: " . mysqli_error($koneksi);
                        }
                        ?>
                        <!-- <textarea class="form-control" rows="5" id="comment" name="text" readonly></textarea> -->

                        <br>   
                        <button onclick="rejectClicked()">Reject</button>

                        <script type="text/javascript">
                            function rejectClicked() {
                                // Display a confirmation dialog
                                if (confirm("Apakah anda ingin mereject?")) {
                                    // User clicked "OK", proceed with rejection
                                    window.location.href = "detail_tawaran.php?status=reject";
                                }
                            }
                        </script> 
                        <a href="detail_tawaran.php?status=<?= urlencode('accept') ?>" class="btn btn-outline-dark">Accept</a>
  

                    </div>
                </div>
            </div>
        </div>
        
    </div>
</body>
</html>